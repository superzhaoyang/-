# -*- coding:utf-8 -*-


from uiObject import uiObject

# main入口
if __name__ == '__main__':

    ui = uiObject()
    ui.ui_process()